# decrypt_secret.py
from Crypto.Cipher import AES
import base64

ciphertext = base64.b64decode("WSmHEPBdtdDblqxXc/Zd8g8fiJeh0sGG8/Uj5Ix8Q6hrbpqBmYtMFnDlqy/LLB23MdT3jKILtWu/ng4vIddNu8VGwaTUPRV0Hv3eckSfQhvh+rGLxgCalCspkm7TMzUpfyOF/9D3MagL49cALfRRreE/gTq8P/aQkVJN5eN2au3e10BY6g+EXl/Frt32NF0sZ8WftIyY3GV0rkosiP33lgtoLb4Q")
nonce = base64.b64decode("FAj6GM2TAR28npE3X64W5A==")
tag = base64.b64decode("GZ9Hcw5WZ0FT5k2EArPDsQ==")
key = base64.b64decode("{ENTER_KEY_HERE}")  # Replace this with the key manually

cipher = AES.new(key, AES.MODE_EAX, nonce)
plaintext = cipher.decrypt_and_verify(ciphertext, tag)
print("Decrypted message:")
print(plaintext.decode())
