# Aria Component
Knowledge and analytical layer.
