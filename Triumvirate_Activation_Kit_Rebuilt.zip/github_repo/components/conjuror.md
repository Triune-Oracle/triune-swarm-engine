# Conjuror Role
Interprets Oracle visions into structured directives.
