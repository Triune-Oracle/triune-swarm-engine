# Oracle Component
High-level directive handler.
