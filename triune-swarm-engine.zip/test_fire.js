// test_fire.js – Test run for swarm logic modules
