// relay_loop.js – Real-time simulation with monetization and memory
