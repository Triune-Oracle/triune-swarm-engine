// loop_engine.js – Core loop for Triumvirate simulation
