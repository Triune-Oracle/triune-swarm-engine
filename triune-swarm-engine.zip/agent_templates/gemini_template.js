// Gemini: Strategic Evaluator
