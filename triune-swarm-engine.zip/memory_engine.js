// memory_engine.js – Tracks agent state and appends memory log
