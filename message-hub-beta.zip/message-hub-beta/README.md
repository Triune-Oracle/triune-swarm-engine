# Message Hub Beta

A lightweight message routing API for AI agent simulation.